a=1;b=a;c=1;d=b;e=d;longname=2;if(longname+1){x=3;if(x)var z=7;}
z=1,y=1,x=1
g+=1;h=g;++i;j=i;i++;j=i+17;